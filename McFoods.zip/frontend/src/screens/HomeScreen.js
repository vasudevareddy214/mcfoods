import { useEffect, useReducer, useState } from 'react';
import axios from 'axios';
import logger from 'use-reducer-logger';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Product from '../components/Product';
import { Helmet } from 'react-helmet-async';
import LoadingBox from '../components/LoadingBox';
import MessageBox from '../components/MessageBox';
// import data from '../data';

const reducer = (state, action) => {
  switch (action.type) {
    case 'FETCH_REQUEST':
      return { ...state, loading: true };
    case 'FETCH_SUCCESS':
      return { ...state, products: action.payload, loading: false };
    case 'FETCH_FAIL':
      return { ...state, loading: false, error: action.payload };
    default:
      return state;
  }
};

function HomeScreen() {
  const [{ loading, error, products }, dispatch] = useReducer(logger(reducer), {
    products: [],
    loading: true,
    error: '',
  });
  // const [products, setProducts] = useState([]);
  useEffect(() => {
    const fetchData = async () => {
      dispatch({ type: 'FETCH_REQUEST' });
      try {
        const result = await axios.get('/api/products');
        dispatch({ type: 'FETCH_SUCCESS', payload: result.data });
      } catch (err) {
        dispatch({ type: 'FETCH_FAIL', payload: err.message });
      }

      // setProducts(result.data);
    };
    fetchData();
  }, []);
  return (
    <div>
      <Helmet>
        <title>McFoods</title>
      </Helmet>
      <h1>Change Your Taste , Make It Better </h1>
      <div classNameName="products">
        {loading ? (
          <LoadingBox />
        ) : error ? (
          <MessageBox variant="danger">{error}</MessageBox>
        ) : (
          <Row>
            {products.map((product) => (
              <Col key={product.slug} sm={6} md={4} lg={3} classNameName="mb-3">
                <Product product={product}></Product>
              </Col>
            ))}
          </Row>
        )}
      </div>
      <footer className="footer">
  	 <div className="container">
  	 	<div className="row">
  	 		<div className="footer-col">
         
         <h4>about us</h4>
  	 			<p>For us,  it's not just about bringing you good food from your favorite restaurant. It's about making a connection, which is why we sit down with 
the chefs, dreaming up menus that will arrive fresh and full of flavor.Try Us.</p>
  	 		</div>
  	 		<div className="footer-col">
  	 			<h4>contact us</h4>
  	 			<ul>
  	 				<li><span>&#9742; </span> &nbsp;1800 110 111</li>
  	 				<li><span>&#9993; </span> &nbsp;mcfoods@gmail.com</li>
  	 				<li><span>&#9775; </span> &nbsp;www.mcfoods.com</li>
  	 				
  	 			</ul>
  	 		</div>
         <div className="footer-col">
  	 			<h4>Serving countries</h4>
  	 			<ul>
  	 				<li>United States</li>
  	 				<li>India</li>
  	 				<li>England</li>
            <li>Australia</li>
            <li>China</li>
  	 				
  	 			</ul>
  	 		</div>
  	 		
  	 		<div className="footer-col">
  	 			<h4>follow us</h4>
  	 			<div className="social-links">
  	 				<a href="http://facebook.com" target='_blank'><i className="fab fa-facebook-f"></i></a>
  	 				<a href="http://twitter.com" target='_blank'><i className="fab fa-twitter"></i></a>
  	 				<a href="http://instagram.com" target='_blank'><i className="fab fa-instagram"></i></a>
  	 				<a href="http://linkedin.com" target='_blank'><i className="fab fa-linkedin-in"></i></a>
          </div>
  	 		</div>
  	 	</div>
  	 </div>
    </footer>
    </div>
  );
}
export default HomeScreen;
