import bcrypt from 'bcryptjs';

const data = {
  users: [
    {
      name: 'Basir',
      email: 'admin@example.com',
      password: bcrypt.hashSync('123456'),
      isAdmin: true,
    },
    {
      name: 'John',
      email: 'user@example.com',
      password: bcrypt.hashSync('123456'),
      isAdmin: false,
    },
  ],
  products: [
    
    {
      name: 'Triple Cheese American Chicken Burger',
      slug: 'Triple Cheese American Chicken Burger',
      category: 'gourmet burgers',
      image: '/images/tripchamchi.png',
      price: 65,
      countInStock: 5,
      brand: 'McFoods',
      rating: 4.5,
      numReviews: 10,
      description: 'Amazing burger with triple layers of cheese stuffed with crispy chicken',
    }
  ],
};
export default data;
